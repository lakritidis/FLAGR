#!/usr/bin/env python
# -*- coding: utf-8 -*-

#from .RAM import *
#from .Comb import *
#from .Majoritarian import *
#from .MarkovChains import *
#from .Weighted import *

#__version__ = '1.0.2'